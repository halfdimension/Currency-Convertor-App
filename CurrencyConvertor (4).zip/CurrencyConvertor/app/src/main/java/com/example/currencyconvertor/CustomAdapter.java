package com.example.currencyconvertor;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class CustomAdapter extends ArrayAdapter<String> {
    private List<String> countries;
    private List<Integer> flags;
    private Context context;

    public CustomAdapter(@NonNull Context context, int resource, @NonNull List<String> countries, List<Integer> flags) {
        super(context, resource, countries);
        this.context = context;
        this.countries = countries;
        this.flags = flags;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return createView(position, convertView, parent);
    }

    @Override
    public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return createView(position, convertView, parent);
    }

    private View createView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.spinner_item_layout, parent, false);
        }

        TextView countryTextView = view.findViewById(R.id.countryTextView);
        ImageView flagImageView = view.findViewById(R.id.flagImageView);

        countryTextView.setText(countries.get(position));
        flagImageView.setImageResource(flags.get(position));

        return view;
    }
}
