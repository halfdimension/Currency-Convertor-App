package com.example.currencyconvertor;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    // Declare UI elements
    TextView textViewHeading, textViewFrom, textViewTo, textViewResult, textViewProject;
    EditText editTextAmount, editTextResult;
    Spinner spinnerFromCurrency, spinnerToCurrency;
    Button btnConvert;
    ImageView flagImageView; // Add ImageView for displaying flag

    // Define conversion rates for different currencies
    Map<String, Double> conversionRates = new HashMap<>();

    // Define flag images for different currencies
    Map<String, Integer> flagImages = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        textViewHeading = findViewById(R.id.textViewHeading);
        textViewFrom = findViewById(R.id.textViewFrom);
        textViewTo = findViewById(R.id.textViewTo);
        textViewResult = findViewById(R.id.textViewResult);
        textViewProject = findViewById(R.id.textViewProject);
        editTextAmount = findViewById(R.id.editTextAmount);
        editTextResult = findViewById(R.id.editTextResult);
        spinnerFromCurrency = findViewById(R.id.spinnerFromCurrency);
        spinnerToCurrency = findViewById(R.id.spinnerToCurrency);
        btnConvert = findViewById(R.id.btnConvert);
        flagImageView = findViewById(R.id.flagImageView); // Initialize flag image view

        // Initialize conversion rates
        initializeConversionRates();

        // Initialize flag images
        initializeFlagImages();

        // Set up spinners for currency selection
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.currencies_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerFromCurrency.setAdapter(adapter);
        spinnerToCurrency.setAdapter(adapter);

        // Set up listener for Convert button
        btnConvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Perform currency conversion
                convertCurrency();
            }
        });
    }

    // Method to initialize conversion rates
    private void initializeConversionRates() {
        // Define conversion rates for different currencies
        conversionRates.put("USD", 1.0); // US Dollar
        conversionRates.put("EUR", 0.85); // Euro
        conversionRates.put("GBP", 0.72); // British Pound Sterling
        conversionRates.put("JPY", 110.33); // Japanese Yen
        conversionRates.put("AUD", 1.30); // Australian Dollar
        conversionRates.put("CAD", 1.25); // Canadian Dollar
        conversionRates.put("CHF", 0.93); // Swiss Franc
        conversionRates.put("CNY", 6.45); // Chinese Yuan Renminbi
        conversionRates.put("INR", 73.31); // Indian Rupee
        conversionRates.put("SGD", 1.36); // Singapore Dollar
        conversionRates.put("NZD", 1.42); // New Zealand Dollar
        conversionRates.put("HKD", 7.77); // Hong Kong Dollar
        conversionRates.put("SEK", 8.54); // Swedish Krona
        conversionRates.put("KRW", 1140.50); // South Korean Won
        conversionRates.put("MXN", 20.03); // Mexican Peso
        // Add conversion rates for other currencies as needed
    }

    // Method to initialize flag images
    private void initializeFlagImages() {
        // Define flag images for different currencies
        flagImages.put("USD", R.drawable.us_flag); // US Dollar
        flagImages.put("EUR", R.drawable.eu_flag); // Euro
        flagImages.put("GBP", R.drawable.uk_flag); // British Pound Sterling
        flagImages.put("JPY", R.drawable.jp_flag); // Japanese Yen
        flagImages.put("AUD", R.drawable.au_flag); // Australian Dollar
        flagImages.put("CAD", R.drawable.ca_flag); // Canadian Dollar
        flagImages.put("CHF", R.drawable.ch_flag); // Swiss Franc
        flagImages.put("CNY", R.drawable.cn_flag); // Chinese Yuan Renminbi
        flagImages.put("INR", R.drawable.in_flag); // Indian Rupee
        flagImages.put("SGD", R.drawable.sg_flag); // Singapore Dollar
        flagImages.put("NZD", R.drawable.nz_flag); // New Zealand Dollar
        flagImages.put("HKD", R.drawable.hk_flag); // Hong Kong Dollar
        flagImages.put("SEK", R.drawable.se_flag); // Swedish Krona
        flagImages.put("KRW", R.drawable.kr_flag); // South Korean Won
        flagImages.put("MXN", R.drawable.mx_flag); // Mexican Peso
        // Add flag images for other currencies as needed
    }

    // Method to perform currency conversion
    private void convertCurrency() {
        String fromCurrency = spinnerFromCurrency.getSelectedItem().toString();
        String toCurrency = spinnerToCurrency.getSelectedItem().toString();
        double amount = Double.parseDouble(editTextAmount.getText().toString());

        // Get conversion rate for selected currencies
        double conversionRate = getConversionRate(fromCurrency, toCurrency);
        if (conversionRate == -1) {
            Toast.makeText(MainActivity.this, "Conversion rate not available", Toast.LENGTH_SHORT).show();
            return;
        }

        // Perform conversion
        double convertedAmount = amount * conversionRate;

        // Append currency symbol based on the selected currency
        String output;
        switch (toCurrency) {
            case "USD":
                output = String.format("$%.2f", convertedAmount); // US Dollar
                break;
            case "EUR":
                output = String.format("€%.2f", convertedAmount); // Euro
                break;
            case "GBP":
                output = String.format("£%.2f", convertedAmount); // British Pound Sterling
                break;
            case "JPY":
                output = String.format("¥%.0f", convertedAmount); // Japanese Yen
                break;
            case "AUD":
                output = String.format("$%.2f", convertedAmount); // Australian Dollar
                break;
            case "CAD":
                output = String.format("$%.2f", convertedAmount); // Canadian Dollar
                break;
            case "CHF":
                output = String.format("CHF %.2f", convertedAmount); // Swiss Franc
                break;
            case "CNY":
                output = String.format("¥%.2f", convertedAmount); // Chinese Yuan Renminbi
                break;
            case "INR":
                output = String.format("₹%.2f", convertedAmount); // Indian Rupee
                break;
            case "SGD":
                output = String.format("$%.2f", convertedAmount); // Singapore Dollar
                break;
            case "NZD":
                output = String.format("$%.2f", convertedAmount); // New Zealand Dollar
                break;
            case "HKD":
                output = String.format("HK$%.2f", convertedAmount); // Hong Kong Dollar
                break;
            case "SEK":
                output = String.format("kr %.2f", convertedAmount); // Swedish Krona
                break;
            case "KRW":
                output = String.format("₩%.0f", convertedAmount); // South Korean Won
                break;
            case "MXN":
                output = String.format("$%.2f MXN", convertedAmount); // Mexican Peso
                break;
            default:
                output = String.format("%.2f", convertedAmount); // Default formatting
        }

        // Set flag image based on selected currency and animate it
        if (flagImages.containsKey(toCurrency)) {
            flagImageView.setImageResource(flagImages.get(toCurrency));
            flagImageView.setVisibility(View.VISIBLE);
            Animation animation = new TranslateAnimation(-400, 0, 0, 0);
            animation.setDuration(1000);
            flagImageView.startAnimation(animation);
        }

        // Display result
        editTextResult.setText(output);
    }

    // Method to get conversion rate for selected currencies
    private double getConversionRate(String fromCurrency, String toCurrency) {
        // You can fetch conversion rates from a database or API
        // For demonstration purposes, using pre-defined conversion rates
        // If conversion rate is not available, return -1
        if (conversionRates.containsKey(fromCurrency) && conversionRates.containsKey(toCurrency)) {
            double fromRate = conversionRates.get(fromCurrency);
            double toRate = conversionRates.get(toCurrency);
            return toRate / fromRate;
        } else {
            return -1;
        }
    }
}
